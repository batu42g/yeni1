'use client'

import { createClient } from '@/lib/supabase/client'
import { useEffect, useState } from 'react'
import {
    Plus, Edit, Trash2, RotateCcw, Loader2,
    CheckCircle2, File, UserPlus, Briefcase, Clock
} from 'lucide-react'

interface AuditEntry {
    id: string
    action_type: 'CREATE' | 'UPDATE' | 'DELETE' | 'RESTORE'
    entity_type: string
    entity_id: string
    description: string | null
    old_value: any
    new_value: any
    created_at: string
    users: { full_name: string; avatar_url: string | null } | null
}

const actionConfig: Record<string, { icon: any; color: string; bg: string; label: string }> = {
    CREATE: { icon: Plus, color: '#34d399', bg: 'rgba(52,211,153,0.1)', label: 'Oluşturuldu' },
    UPDATE: { icon: Edit, color: '#60a5fa', bg: 'rgba(96,165,250,0.1)', label: 'Güncellendi' },
    DELETE: { icon: Trash2, color: '#f87171', bg: 'rgba(248,113,113,0.1)', label: 'Silindi' },
    RESTORE: { icon: RotateCcw, color: '#a78bfa', bg: 'rgba(167,139,250,0.1)', label: 'Geri Yüklendi' },
}

const entityLabels: Record<string, string> = {
    task: 'Görev',
    project: 'Proje',
    customer: 'Müşteri',
    offer: 'Teklif',
    invitation: 'Davet',
    company: 'Şirket',
    project_file: 'Dosya',
}

function timeAgo(date: string) {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000)
    if (seconds < 60) return 'Az önce'
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes} dk önce`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours} saat önce`
    const days = Math.floor(hours / 24)
    if (days < 7) return `${days} gün önce`
    return new Date(date).toLocaleDateString('tr-TR')
}

export function ActivityTimeline({ projectId }: { projectId: string }) {
    const [entries, setEntries] = useState<AuditEntry[]>([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const fetchTimeline = async () => {
            const supabase = createClient()

            const { data, error } = await supabase
                .from('audit_logs')
                .select(`
                    *,
                    users:user_id (full_name, avatar_url)
                `)
                .or(`and(entity_type.eq.project,entity_id.eq.${projectId}),and(entity_type.eq.task,entity_id.in.(select id from tasks where project_id='${projectId}'))`)
                .order('created_at', { ascending: false })
                .limit(30)

            if (error) {
                // Fallback
                const { data: fallback } = await supabase
                    .from('audit_logs')
                    .select(`*, users:user_id (full_name, avatar_url)`)
                    .order('created_at', { ascending: false })
                    .limit(30)
                setEntries((fallback as any) || [])
            } else {
                setEntries((data as any) || [])
            }

            setLoading(false)
        }

        fetchTimeline()
    }, [projectId])

    if (loading) {
        return (
            <div className="flex justify-center items-center py-16">
                <Loader2 className="w-6 h-6 animate-spin" style={{ color: 'var(--color-text-3)' }} />
            </div>
        )
    }

    if (entries.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center py-16" style={{ color: 'var(--color-text-3)' }}>
                <Clock className="w-10 h-10 mb-3" style={{ color: 'var(--color-text-3)' }} />
                <p className="text-sm">Henüz aktivite kaydı yok</p>
            </div>
        )
    }

    return (
        <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-[19px] top-2 bottom-2 w-px" style={{ background: 'var(--color-border)' }} />

            <div className="space-y-0 relative">
                {entries.map((entry, i) => {
                    const config = actionConfig[entry.action_type] || actionConfig.UPDATE
                    const Icon = config.icon

                    return (
                        <div
                            key={entry.id}
                            className="relative flex gap-4 py-4 group"
                            style={{
                                animationDelay: `${i * 50}ms`,
                                animation: 'fadeInUp 0.3s ease forwards',
                                opacity: 0,
                            }}
                        >
                            {/* Dot */}
                            <div
                                className="relative z-10 flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center border transition-transform group-hover:scale-110"
                                style={{
                                    background: config.bg,
                                    borderColor: config.color + '30',
                                }}
                            >
                                <Icon className="w-4 h-4" style={{ color: config.color }} />
                            </div>

                            {/* Content */}
                            <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between gap-2">
                                    <div>
                                        <p className="text-sm" style={{ color: 'var(--color-text-0)' }}>
                                            <span className="font-medium" style={{ color: config.color }}>
                                                {config.label}
                                            </span>
                                            {' — '}
                                            <span style={{ color: 'var(--color-text-2)' }}>
                                                {entityLabels[entry.entity_type] || entry.entity_type}
                                            </span>
                                        </p>
                                        {entry.description && (
                                            <p className="text-xs mt-0.5 truncate max-w-md" style={{ color: 'var(--color-text-3)' }}>
                                                {entry.description}
                                            </p>
                                        )}
                                    </div>
                                    <span className="text-xs whitespace-nowrap flex-shrink-0" style={{ color: 'var(--color-text-3)' }}>
                                        {timeAgo(entry.created_at)}
                                    </span>
                                </div>

                                {/* User info */}
                                {entry.users && (
                                    <div className="flex items-center gap-1.5 mt-1.5">
                                        <div className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold" style={{ background: 'var(--color-surface-3)', color: 'var(--color-text-2)' }}>
                                            {entry.users.full_name?.charAt(0)}
                                        </div>
                                        <span className="text-[11px]" style={{ color: 'var(--color-text-3)' }}>
                                            {entry.users.full_name}
                                        </span>
                                    </div>
                                )}
                            </div>
                        </div>
                    )
                })}
            </div>

            <style jsx>{`
                @keyframes fadeInUp {
                    from {
                        opacity: 0;
                        transform: translateY(8px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            `}</style>
        </div>
    )
}

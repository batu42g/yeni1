'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useAuthStore } from '@/store/auth-store'

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const router = useRouter()
    const { setUser, setLoading } = useAuthStore()

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const supabase = createClient()
                const { data: { session } } = await supabase.auth.getSession()

                if (!session) {
                    setUser(null)
                    setLoading(false)
                    return
                }

                // Centralized bootstrap call for all context
                const res = await fetch('/api/context/bootstrap')
                if (res.status === 401) {
                    setUser(null)
                    return
                }

                if (!res.ok) throw new Error('Bootstrap failed')

                const data = await res.json()

                if (data.user) {
                    setUser({
                        id: data.user.id,
                        active_company_id: data.active_company_id,
                        role: data.role,
                        full_name: data.user.full_name,
                        avatar_url: data.user.avatar_url,
                        email: data.user.email || '',
                        onboarding: data.onboarding
                    })
                } else {
                    setUser(null)
                }
            } catch (error) {
                console.error('AuthProvider fetch error:', error)
                setUser(null)
            } finally {
                setLoading(false)
            }
        }

        const supabase = createClient()

        fetchProfile()

        const { data: { subscription } } = supabase.auth.onAuthStateChange(
            async (event) => {
                if (event === 'SIGNED_OUT') {
                    setUser(null)
                    router.push('/login')
                } else if (event === 'SIGNED_IN') {
                    fetchProfile()
                }
            }
        )

        return () => {
            subscription.unsubscribe()
        }
    }, [setUser, setLoading, router])

    return <>{children}</>
}

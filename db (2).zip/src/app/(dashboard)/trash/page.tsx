'use client'

import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useAuthStore } from '@/store/auth-store'
import { formatDate } from '@/lib/utils'
import { EmptyState } from '@/components/ui/empty-state'
import toast from 'react-hot-toast'
import {
    Trash2,
    RotateCcw,
    Users,
    FolderKanban,
    ListTodo,
    FileText,
    Loader2,
    AlertTriangle,
} from 'lucide-react'

type EntityTab = 'customers' | 'projects' | 'tasks' | 'offers'

interface DeletedItem {
    id: string
    name?: string
    title?: string
    amount?: number
    status?: string
    deleted_at: string
    created_at: string
}

const TABS: { id: EntityTab; label: string; icon: any }[] = [
    { id: 'customers', label: 'Müşteriler', icon: Users },
    { id: 'projects', label: 'Projeler', icon: FolderKanban },
    { id: 'tasks', label: 'Görevler', icon: ListTodo },
    { id: 'offers', label: 'Teklifler', icon: FileText },
]

export default function TrashPage() {
    const { user } = useAuthStore()
    const [activeTab, setActiveTab] = useState<EntityTab>('customers')
    const [items, setItems] = useState<DeletedItem[]>([])
    const [loading, setLoading] = useState(true)
    const [restoring, setRestoring] = useState<string | null>(null)
    const [permanentDelete, setPermanentDelete] = useState<string | null>(null)

    const fetchDeleted = useCallback(async () => {
        if (!user) return
        setLoading(true)
        const supabase = createClient()

        const selectMap: Record<EntityTab, string> = {
            customers: 'id, name, status, deleted_at, created_at',
            projects: 'id, title, status, deleted_at, created_at',
            tasks: 'id, title, status, deleted_at, created_at',
            offers: 'id, amount, status, deleted_at, created_at',
        }

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const { data, error } = await (supabase as any)
            .from(activeTab)
            .select(selectMap[activeTab])
            .eq('company_id', user.active_company_id!)
            .not('deleted_at', 'is', null)
            .order('deleted_at', { ascending: false })

        if (!error) {
            setItems((data as unknown as DeletedItem[]) || [])
        }
        setLoading(false)
    }, [user, activeTab])

    useEffect(() => {
        fetchDeleted()
    }, [fetchDeleted])

    const handleRestore = async (id: string) => {
        setRestoring(id)
        const supabase = createClient()

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const { error } = await (supabase as any)
            .from(activeTab)
            .update({ deleted_at: null })
            .eq('id', id)

        if (error) {
            toast.error('Geri yükleme başarısız')
        } else {
            toast.success('Başarıyla geri yüklendi')
            setItems(prev => prev.filter(i => i.id !== id))
        }
        setRestoring(null)
    }

    const handlePermanentDelete = async (id: string) => {
        const supabase = createClient()

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const { error } = await (supabase as any)
            .from(activeTab)
            .delete()
            .eq('id', id)

        if (error) {
            toast.error('Kalıcı silme başarısız')
        } else {
            toast.success('Kalıcı olarak silindi')
            setItems(prev => prev.filter(i => i.id !== id))
        }
        setPermanentDelete(null)
    }

    const getItemLabel = (item: DeletedItem) => {
        if (item.name) return item.name
        if (item.title) return item.title
        if (item.amount) return `₺${item.amount.toLocaleString('tr-TR')}`
        return item.id.slice(0, 8)
    }

    return (
        <div className="space-y-6 animate-fade-in">
            <div>
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-0)' }}>
                    <Trash2 className="w-5 h-5 inline-block mr-2" style={{ color: 'var(--color-danger)' }} />
                    Çöp Kutusu
                </h2>
                <p className="text-sm mt-1" style={{ color: 'var(--color-text-3)' }}>
                    Silinen öğeleri geri yükleyin veya kalıcı olarak silin.
                </p>
            </div>

            {/* Tabs */}
            <div className="flex items-center gap-1 border-b overflow-x-auto" style={{ borderColor: 'var(--color-border)' }}>
                {TABS.map(tab => {
                    const Icon = tab.icon
                    return (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className="flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2 whitespace-nowrap"
                            style={{
                                borderColor: activeTab === tab.id ? 'var(--color-accent)' : 'transparent',
                                color: activeTab === tab.id ? 'var(--color-text-0)' : 'var(--color-text-3)',
                            }}
                        >
                            <Icon className="w-4 h-4" />
                            {tab.label}
                        </button>
                    )
                })}
            </div>

            {/* Content */}
            {loading ? (
                <div className="flex justify-center py-16">
                    <Loader2 className="w-6 h-6 animate-spin" style={{ color: 'var(--color-text-3)' }} />
                </div>
            ) : items.length === 0 ? (
                <EmptyState
                    title="Çöp kutusu boş"
                    description={`Silinen ${TABS.find(t => t.id === activeTab)?.label.toLowerCase()} bulunamadı.`}
                    icon={<Trash2 className="w-7 h-7" style={{ color: 'var(--color-text-3)' }} />}
                />
            ) : (
                <div className="rounded-xl overflow-hidden" style={{ background: 'var(--color-surface-1)', border: '1px solid var(--color-border)' }}>
                    <div className="overflow-x-auto">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Ad</th>
                                    <th>Silinme Tarihi</th>
                                    <th className="text-right">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                {items.map((item, i) => (
                                    <tr key={item.id} className="animate-fade-in" style={{ animationDelay: `${i * 40}ms` }}>
                                        <td>
                                            <span className="font-medium" style={{ color: 'var(--color-text-0)' }}>
                                                {getItemLabel(item)}
                                            </span>
                                        </td>
                                        <td style={{ color: 'var(--color-text-2)' }}>
                                            {formatDate(item.deleted_at)}
                                        </td>
                                        <td>
                                            <div className="flex items-center justify-end gap-2">
                                                <button
                                                    onClick={() => handleRestore(item.id)}
                                                    disabled={restoring === item.id}
                                                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                    style={{
                                                        background: 'var(--color-accent-glow)',
                                                        color: 'var(--color-accent)',
                                                    }}
                                                >
                                                    {restoring === item.id ? (
                                                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                                    ) : (
                                                        <RotateCcw className="w-3.5 h-3.5" />
                                                    )}
                                                    Geri Yükle
                                                </button>
                                                {permanentDelete === item.id ? (
                                                    <div className="flex items-center gap-1">
                                                        <button
                                                            onClick={() => handlePermanentDelete(item.id)}
                                                            className="px-2 py-1 rounded text-xs font-medium transition-colors"
                                                            style={{ background: 'var(--color-danger)', color: '#fff' }}
                                                        >
                                                            Evet, Sil
                                                        </button>
                                                        <button
                                                            onClick={() => setPermanentDelete(null)}
                                                            className="px-2 py-1 rounded text-xs"
                                                            style={{ color: 'var(--color-text-3)' }}
                                                        >
                                                            İptal
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <button
                                                        onClick={() => setPermanentDelete(item.id)}
                                                        className="btn-ghost p-2"
                                                        style={{ color: 'var(--color-danger)' }}
                                                        title="Kalıcı Sil"
                                                    >
                                                        <Trash2 className="w-3.5 h-3.5" />
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    )
}

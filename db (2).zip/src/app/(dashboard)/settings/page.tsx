import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { UsersTable } from '@/components/settings/UsersTable'
import { InviteUser } from '@/components/settings/InviteUser'
import { InvitationsTable } from '@/components/settings/InvitationsTable'
import { CompanyProfileForm } from '@/components/settings/CompanyProfileForm'
import { BackupExport } from '@/components/settings/BackupExport'
import { DangerZone } from '@/components/settings/DangerZone'
import { User, Users, Settings2, Building, Database } from 'lucide-react'
import Link from 'next/link'

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
    const { tab } = await searchParams
    const activeTab = tab || 'profile'

    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
        redirect('/login')
    }



    // Use the smart RPC to get the current profile and active company
    const { data: profileData, error: profileError } = await supabase
        .rpc('ensure_user_context' as any)
        .single()

    if (profileError || !profileData) {
        return <div className="p-8 text-center text-red-500">Kullanıcı bağlamı oluşturulamadı.</div>
    }

    const profile = profileData as any
    const companyId = profile.company_id

    const { data: companyData, error: companyError } = await supabase
        .from('companies')
        .select('*')
        .eq('id', companyId)
        .single()

    if (!companyData) {
        return (
            <div className="p-8 text-center space-y-4">
                <div className="text-red-500">Şirket bilgisi bulunamadı.</div>
                <p className="text-sm text-gray-500">Hesabınız bir şirkete bağlı değil veya silinmiş.</p>
                <Link href="/setup-company" className="inline-block px-4 py-2 bg-blue-600 text-white rounded-md">
                    Yeni Şirket Kur
                </Link>
            </div>
        )
    }

    // Check if user is owner via members table (or fallback to legacy role if needed)
    const { data: member } = await supabase
        .from('members')
        .select('role')
        .eq('user_id', user.id)
        .eq('company_id', companyData.id)
        .single()

    const isOwner = member?.role === 'owner' || (profile as any).role === 'owner'
    const isAdmin = member?.role === 'admin' || isOwner || (profile as any).role === 'admin'

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text-0)' }}>Ayarlar</h1>

            {/* Tabs Navigation */}
            <div className="flex items-center gap-1 border-b overflow-x-auto" style={{ borderColor: 'var(--color-border)' }}>
                <Link
                    href="/settings?tab=profile"
                    className="flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2 whitespace-nowrap"
                    style={{
                        borderColor: activeTab === 'profile' ? 'var(--color-accent)' : 'transparent',
                        color: activeTab === 'profile' ? 'var(--color-text-0)' : 'var(--color-text-3)',
                    }}
                >
                    <Building className="w-4 h-4" />
                    Şirket Profili
                </Link>
                <Link
                    href="/settings?tab=users"
                    className="flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2 whitespace-nowrap"
                    style={{
                        borderColor: activeTab === 'users' ? 'var(--color-accent)' : 'transparent',
                        color: activeTab === 'users' ? 'var(--color-text-0)' : 'var(--color-text-3)',
                    }}
                >
                    <Users className="w-4 h-4" />
                    Kullanıcılar & Davet
                </Link>
                {isAdmin && (
                    <Link
                        href="/settings?tab=backup"
                        className="flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2 whitespace-nowrap"
                        style={{
                            borderColor: activeTab === 'backup' ? 'var(--color-accent)' : 'transparent',
                            color: activeTab === 'backup' ? 'var(--color-text-0)' : 'var(--color-text-3)',
                        }}
                    >
                        <Database className="w-4 h-4" />
                        Yedekleme
                    </Link>
                )}
            </div>

            {/* Content Area */}
            <div className="min-h-[400px]">
                {activeTab === 'profile' && (
                    <div className="rounded-xl p-8 animate-in fade-in zoom-in-95 duration-300" style={{ background: 'var(--color-surface-1)', border: '1px solid var(--color-border)' }}>
                        <div className="max-w-4xl">
                            <CompanyProfileForm
                                companyId={companyData.id}
                                initialName={companyData.name}
                                initialLogoUrl={companyData.logo_url}
                            />

                            <div className="mt-8 pt-8 border-t" style={{ borderColor: 'var(--color-border)' }}>
                                <DangerZone
                                    companyId={companyData.id}
                                    companyName={companyData.name}
                                    currentUserId={user.id}
                                    currentUserRole={isOwner ? 'owner' : (isAdmin ? 'admin' : 'staff')}
                                />
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'users' && (
                    <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
                        {/* Invite Section (Only Admin) */}
                        {isAdmin && (
                            <div className="space-y-6">
                                <div className="rounded-xl p-6" style={{ background: 'var(--color-surface-1)', border: '1px solid var(--color-border)' }}>
                                    <h2 className="text-lg font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--color-text-0)' }}>
                                        <User className="w-5 h-5" style={{ color: 'var(--color-accent)' }} />
                                        Yeni Kullanıcı Davet Et
                                    </h2>
                                    <InviteUser companyId={companyData.id} />
                                </div>
                                <div className="rounded-xl p-6" style={{ background: 'var(--color-surface-1)', border: '1px solid var(--color-border)' }}>
                                    <InvitationsTable companyId={companyData.id} />
                                </div>
                            </div>
                        )}

                        {/* Users List */}
                        <div className="rounded-xl p-6" style={{ background: 'var(--color-surface-1)', border: '1px solid var(--color-border)' }}>
                            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--color-text-0)' }}>
                                <Users className="w-5 h-5" style={{ color: 'var(--color-accent)' }} />
                                Ekip Üyeleri
                            </h2>
                            <UsersTable
                                companyId={companyData.id}
                                sessionId={user.id}
                                currentUserRole={isOwner ? 'owner' : (isAdmin ? 'admin' : 'staff')}
                            />
                        </div>
                    </div>
                )}

                {activeTab === 'backup' && isAdmin && (
                    <div className="rounded-xl p-8 animate-in fade-in zoom-in-95 duration-300" style={{ background: 'var(--color-surface-1)', border: '1px solid var(--color-border)' }}>
                        <BackupExport />
                    </div>
                )}
            </div>
        </div>
    )
}

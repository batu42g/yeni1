'use client'

import { useState, useEffect, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useAuthStore } from '@/store/auth-store'
import { formatCurrency } from '@/lib/utils'
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    AreaChart,
    Area,
    PieChart,
    Pie,
    Cell,
    LineChart,
    Line,
    Legend
} from 'recharts'
import { Calendar, TrendingUp, PieChart as PieIcon, Activity } from 'lucide-react'

export default function ReportsPage() {
    const { user } = useAuthStore()
    const [loading, setLoading] = useState(true)
    const [monthlyData, setMonthlyData] = useState<any[]>([])
    const [statusData, setStatusData] = useState<any[]>([])
    const [offerConversionData, setOfferConversionData] = useState<any[]>([])

    const fetchReportsData = useCallback(async () => {
        if (!user) return
        const supabase = createClient()

        try {
            const currentYear = new Date().getFullYear()

            // Parallel fetch
            const [projectsRes, offersRes] = await Promise.all([
                supabase.from('projects').select('id, budget, status, created_at').eq('company_id', user.active_company_id!),
                supabase.from('offers').select('id, amount, status, created_at').eq('company_id', user.active_company_id!)
            ])

            const projects = projectsRes.data || []
            const offers = offersRes.data || []

            // 1. Monthly Financials (Revenue vs Potential)
            const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara']
            const monthlyStats = months.map((month, i) => {
                const monthProjects = projects.filter(p => new Date(p.created_at).getMonth() === i && new Date(p.created_at).getFullYear() === currentYear)
                const monthOffers = offers.filter(o => new Date(o.created_at).getMonth() === i && new Date(o.created_at).getFullYear() === currentYear)

                return {
                    name: month,
                    revenue: monthProjects.reduce((sum, p) => sum + (p.budget || 0), 0),
                    potential: monthOffers.reduce((sum, o) => sum + (o.amount || 0), 0),
                }
            })
            setMonthlyData(monthlyStats)

            // 2. Project Status Distribution
            const statusCounts = projects.reduce((acc: any, p) => {
                const status = p.status || 'unknown'
                acc[status] = (acc[status] || 0) + 1
                return acc
            }, {})

            const statusChartData = [
                { name: 'Devam Eden', value: statusCounts['in_progress'] || 0, color: 'var(--color-info)' },
                { name: 'Tamamlanan', value: statusCounts['completed'] || 0, color: 'var(--color-success)' },
                { name: 'İptal', value: statusCounts['cancelled'] || 0, color: 'var(--color-danger)' },
                { name: 'Beklemede', value: statusCounts['on_hold'] || 0, color: 'var(--color-warn)' },
            ].filter(i => i.value > 0)
            setStatusData(statusChartData)

            // 3. Offer Conversion Rate for last 6 months
            // This is complex, let's simplify: Monthly approved vs total offers count
            const conversionStats = months.slice(0, new Date().getMonth() + 1).map((month, i) => {
                const total = offers.filter(o => new Date(o.created_at).getMonth() === i && new Date(o.created_at).getFullYear() === currentYear).length
                const approved = offers.filter(o => new Date(o.created_at).getMonth() === i && new Date(o.created_at).getFullYear() === currentYear && o.status === 'approved').length

                return {
                    name: month,
                    rate: total > 0 ? Math.round((approved / total) * 100) : 0,
                    total,
                    approved
                }
            })
            setOfferConversionData(conversionStats)

        } catch (error) {
            console.error('Error fetching reports:', error)
        } finally {
            setLoading(false)
        }
    }, [user])

    useEffect(() => {
        fetchReportsData()
    }, [fetchReportsData])

    if (loading) {
        return <div className="p-8 text-center text-gray-500">Veriler analiz ediliyor...</div>
    }

    return (
        <div className="space-y-8 animate-fade-in max-w-7xl mx-auto">
            <div>
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text-0)' }}>Gelişmiş Raporlar</h1>
                <p className="text-sm mt-2" style={{ color: 'var(--color-text-3)' }}>
                    İşletmenizin performans metrikleri ve finansal analizi.
                </p>
            </div>

            {/* Financial Overview Chart */}
            <div className="p-6 rounded-2xl border" style={{ background: 'var(--color-surface-1)', borderColor: 'var(--color-border)' }}>
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h3 className="text-lg font-bold flex items-center gap-2" style={{ color: 'var(--color-text-0)' }}>
                            <TrendingUp className="w-5 h-5 text-indigo-500" />
                            Finansal Genel Bakış
                        </h3>
                        <p className="text-xs text-gray-500">Proje Gelirleri vs. Teklif Potansiyeli</p>
                    </div>
                </div>
                <div className="h-[350px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={monthlyData}>
                            <defs>
                                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.2} />
                                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="colorPotential" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                            <XAxis dataKey="name" stroke="var(--color-text-3)" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="var(--color-text-3)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `₺${val / 1000}k`} />
                            <Tooltip
                                contentStyle={{ background: 'var(--color-surface-2)', border: '1px solid var(--color-border)', borderRadius: '8px', color: 'var(--color-text-0)' }}
                                itemStyle={{ color: 'var(--color-text-0)' }}
                                formatter={(val: number | undefined) => formatCurrency(val || 0)}
                            />
                            <Legend />
                            <Area type="monotone" dataKey="potential" name="Teklif Potansiyeli" stroke="#6366f1" fillOpacity={1} fill="url(#colorPotential)" strokeWidth={2} />
                            <Area type="monotone" dataKey="revenue" name="Gerçekleşen Gelir" stroke="#22c55e" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Project Status Distribution */}
                <div className="p-6 rounded-2xl border" style={{ background: 'var(--color-surface-1)', borderColor: 'var(--color-border)' }}>
                    <h3 className="text-lg font-bold flex items-center gap-2 mb-6" style={{ color: 'var(--color-text-0)' }}>
                        <PieIcon className="w-5 h-5 text-amber-500" />
                        Proje Durum Dağılımı
                    </h3>
                    <div className="h-[300px] w-full flex items-center justify-center">
                        {statusData.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={statusData}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={80}
                                        outerRadius={110}
                                        paddingAngle={5}
                                        dataKey="value"
                                    >
                                        {statusData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                                        ))}
                                    </Pie>
                                    <Tooltip
                                        contentStyle={{ background: 'var(--color-surface-2)', border: 'none', borderRadius: '8px' }}
                                    />
                                    <Legend verticalAlign="bottom" height={36} />
                                </PieChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="text-gray-500 text-sm">Veri bulunamadı</div>
                        )}
                    </div>
                </div>

                {/* Offer Conversion Rate */}
                <div className="p-6 rounded-2xl border" style={{ background: 'var(--color-surface-1)', borderColor: 'var(--color-border)' }}>
                    <h3 className="text-lg font-bold flex items-center gap-2 mb-6" style={{ color: 'var(--color-text-0)' }}>
                        <Activity className="w-5 h-5 text-blue-500" />
                        Teklif Dönüşüm Oranı (%)
                    </h3>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={offerConversionData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                                <XAxis dataKey="name" stroke="var(--color-text-3)" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="var(--color-text-3)" fontSize={12} tickLine={false} axisLine={false} unit="%" />
                                <Tooltip
                                    cursor={{ fill: 'var(--color-surface-2)' }}
                                    contentStyle={{ background: 'var(--color-surface-2)', border: '1px solid var(--color-border)', borderRadius: '8px', color: 'var(--color-text-0)' }}
                                />
                                <Bar dataKey="rate" name="Onay Oranı" fill="var(--color-accent)" radius={[4, 4, 0, 0]} barSize={40} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    )
}

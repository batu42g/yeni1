'use client'

import { useEffect, useState } from 'react'
import { Activity, Search, AlertTriangle, AlertCircle, Info } from 'lucide-react'
import { parseUTCDate } from '@/lib/utils'
import { formatDistanceToNow } from 'date-fns'
import { tr } from 'date-fns/locale'
import { useAuthStore } from '@/store/auth-store'

export default function ActivityPage() {
    const { user } = useAuthStore()
    const [events, setEvents] = useState<any[]>([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const fetchActivity = async () => {
            if (!user) return
            try {
                const res = await fetch('/api/activity')
                const data = await res.json()
                if (data.events) {
                    setEvents(data.events)
                }
            } catch (err) {
                console.error(err)
            } finally {
                setLoading(false)
            }
        }

        // Wait till we know user is fully loaded and active company is checked
        if (user?.active_company_id) {
            fetchActivity()
        }
    }, [user])

    const getSeverityIcon = (sev: string) => {
        switch (sev) {
            case 'critical': return <AlertTriangle className="w-5 h-5 text-red-500" />
            case 'warning': return <AlertCircle className="w-5 h-5 text-yellow-500" />
            default: return <Info className="w-5 h-5 text-blue-500" />
        }
    }

    return (
        <div className="max-w-5xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                        <Activity className="w-6 h-6 text-indigo-400" /> Hesap Hareketleri
                    </h1>
                    <p className="text-sm text-gray-400 mt-1">
                        Hesabınız ve şirketinizdeki son operasyonel gelişmeler.
                    </p>
                </div>

                <div className="relative">
                    <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                        type="text"
                        placeholder="Etkinlik ara..."
                        className="pl-9 pr-4 py-2 bg-[#0f0f13] border border-gray-800 rounded-lg text-sm text-white focus:outline-none focus:border-indigo-500"
                    />
                </div>
            </div>

            {loading ? (
                <div className="flex justify-center p-12">
                    <div className="w-8 h-8 rounded-full border-t-2 border-indigo-500 animate-spin"></div>
                </div>
            ) : events.length === 0 ? (
                <div className="text-center p-12 bg-[#1a1a26] rounded-xl border border-gray-800">
                    <p className="text-gray-400">Henüz bir etkinlik bulunmuyor.</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {events.map((ev) => (
                        <div key={ev.id} className="flex gap-4 p-5 bg-[#1a1a26] border border-gray-800 rounded-xl hover:bg-[#1f1f2e] transition-colors">
                            <div className="mt-1">
                                {getSeverityIcon(ev.severity)}
                            </div>
                            <div className="flex-1">
                                <div className="flex items-start justify-between">
                                    <h3 className="font-medium text-white">{ev.title}</h3>
                                    <span className="text-xs text-gray-500">
                                        {formatDistanceToNow(parseUTCDate(ev.created_at), { addSuffix: true, locale: tr })}
                                    </span>
                                </div>
                                <p className="text-sm text-gray-400 mt-1">{ev.summary}</p>
                                <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
                                    {ev.actor && (
                                        <div className="flex items-center gap-2">
                                            <div className="w-5 h-5 rounded-full bg-gray-700 overflow-hidden flex items-center justify-center">
                                                {ev.actor.avatar_url ? (
                                                    <img src={ev.actor.avatar_url} alt="" className="w-full h-full object-cover" />
                                                ) : (
                                                    <span className="text-[10px] text-white">{(ev.actor.full_name || '?').charAt(0)}</span>
                                                )}
                                            </div>
                                            <span>{ev.actor.full_name || 'Bilinmeyen Kullanıcı'}</span>
                                        </div>
                                    )}
                                    <span className="px-2 py-0.5 rounded-full bg-gray-800 border border-gray-700">
                                        {ev.event_type}
                                    </span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}

'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useAuthStore } from '@/store/auth-store'
import QRCode from 'qrcode'
import toast from 'react-hot-toast'
import { ShieldCheck, Lock, Smartphone, RefreshCw, Copy, Check, AlertTriangle } from 'lucide-react'

export default function SecurityPage() {
    const { user } = useAuthStore()
    const [loading, setLoading] = useState(true)
    const [isEnabled, setIsEnabled] = useState(false)
    const [enrollFactorId, setEnrollFactorId] = useState('')
    const [qrCodeUrl, setQrCodeUrl] = useState('')
    const [secret, setSecret] = useState('')
    const [verifyCode, setVerifyCode] = useState('')
    const [showEnroll, setShowEnroll] = useState(false)
    const [copied, setCopied] = useState(false)

    useEffect(() => {
        checkMfaStatus()
    }, [user])

    const checkMfaStatus = async () => {
        if (!user) return
        const supabase = createClient()
        try {
            const { data, error } = await supabase.auth.mfa.listFactors()
            if (error) throw error

            const totpFactor = data.totp.find(f => f.status === 'verified')
            setIsEnabled(!!totpFactor)

            // Clean up unverified factors if any (optional but good for hygiene)
            // @ts-ignore - Supabase types can be strict about literal types
            const unverified = data.totp.filter(f => f.status === 'unverified')
            if (unverified.length > 0) {
                unverified.forEach(async (f) => {
                    await supabase.auth.mfa.unenroll({ factorId: f.id })
                })
            }
        } catch (error) {
            console.error('MFA Check Error:', error)
        } finally {
            setLoading(false)
        }
    }

    const startEnrollment = async () => {
        setLoading(true)
        const supabase = createClient()
        try {
            const { data, error } = await supabase.auth.mfa.enroll({
                factorType: 'totp',
            })

            if (error) throw error

            setEnrollFactorId(data.id)
            setSecret(data.totp.secret)

            // Supabase returns a QR code SVG usually, but let's generate our own from URI to be safe and consistent
            // data.totp.uri is otpauth://...
            if (data.totp.uri) {
                const url = await QRCode.toDataURL(data.totp.uri)
                setQrCodeUrl(url)
            }

            setShowEnroll(true)
        } catch (error: any) {
            toast.error(error.message || 'MFA başlatılamadı')
        } finally {
            setLoading(false)
        }
    }

    const verifyAndActivate = async () => {
        if (!verifyCode || verifyCode.length !== 6) {
            toast.error('Lütfen 6 haneli kodu girin')
            return
        }
        setLoading(true)
        const supabase = createClient()

        try {
            const { data, error } = await supabase.auth.mfa.challengeAndVerify({
                factorId: enrollFactorId,
                code: verifyCode,
            })

            if (error) throw error

            toast.success('2FA Başarıyla Aktifleştirildi! 🎉')
            setIsEnabled(true)
            setShowEnroll(false)
            setVerifyCode('')
        } catch (error: any) {
            console.error('Verify Error:', error)
            toast.error(error.message || 'Kod doğrulanamadı. Tekrar deneyin.')
        } finally {
            setLoading(false)
        }
    }

    const disableMFA = async () => {
        if (!confirm('2FA korumasını kaldırmak istediğinize emin misiniz?')) return

        setLoading(true)
        const supabase = createClient()

        try {
            const { data } = await supabase.auth.mfa.listFactors()
            const factor = data?.totp.find(f => f.status === 'verified')

            if (!factor) return

            const { error } = await supabase.auth.mfa.unenroll({ factorId: factor.id })
            if (error) throw error

            toast.success('2FA devre dışı bırakıldı')
            setIsEnabled(false)
        } catch (error: any) {
            toast.error(error.message || 'İşlem başarısız')
        } finally {
            setLoading(false)
        }
    }

    const copySecret = () => {
        navigator.clipboard.writeText(secret)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
        toast.success('Secret kopyalandı')
    }

    if (loading && !showEnroll && !isEnabled) {
        return <div className="p-8 text-center text-gray-500">Yükleniyor...</div>
    }

    return (
        <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
            <div>
                <h1 className="text-3xl font-bold" style={{ color: 'var(--color-text-0)' }}>Hesap Güvenliği</h1>
                <p className="text-sm mt-2" style={{ color: 'var(--color-text-3)' }}>
                    Hesabınızı korumak için güvenlik ayarlarınızı yönetin.
                </p>
            </div>

            <div className="p-6 rounded-2xl border" style={{ background: 'var(--color-surface-1)', borderColor: 'var(--color-border)' }}>
                <div className="flex items-start justify-between">
                    <div className="flex gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${isEnabled ? 'bg-green-500/10 text-green-500' : 'bg-gray-500/10 text-gray-500'}`}>
                            <ShieldCheck className="w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="text-lg font-bold" style={{ color: 'var(--color-text-0)' }}>
                                İki Aşamalı Doğrulama (2FA)
                            </h3>
                            <p className="text-sm text-gray-500 mt-1 max-w-lg">
                                Hesabınıza giriş yaparken şifrenize ek olarak telefonunuzdaki uygulamadan üretilen geçici bir kod ister.
                                Bu, hesabınızın çalınmasını neredeyse imkansız hale getirir.
                            </p>
                            <div className="mt-3 flex items-center gap-2">
                                <span className={`text-xs px-2.5 py-0.5 rounded-full font-medium border ${isEnabled ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-gray-500/10 text-gray-500 border-gray-500/20'}`}>
                                    {isEnabled ? 'AKTİF' : 'PASİF'}
                                </span>
                            </div>
                        </div>
                    </div>

                    {!showEnroll && (
                        <button
                            onClick={isEnabled ? disableMFA : startEnrollment}
                            disabled={loading}
                            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${isEnabled
                                ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20'
                                : 'bg-indigo-600 text-white hover:bg-indigo-700'
                                }`}
                        >
                            {isEnabled ? 'Devre Dışı Bırak' : 'Kurulumu Başlat'}
                        </button>
                    )}
                </div>

                {/* Enrollment Flow */}
                {showEnroll && (
                    <div className="mt-8 pt-8 border-t border-gray-800 animation-expand">
                        <div className="grid md:grid-cols-2 gap-8">
                            <div className="flex flex-col items-center justify-center p-6 bg-white rounded-xl">
                                {qrCodeUrl ? (
                                    <img src={qrCodeUrl} alt="2FA QR Code" className="w-48 h-48" />
                                ) : (
                                    <div className="w-48 h-48 bg-gray-200 animate-pulse rounded" />
                                )}
                                <p className="text-xs text-black/60 mt-4 text-center">
                                    Google Authenticator veya Authy uygulamasıyla taratın.
                                </p>
                            </div>

                            <div className="space-y-6">
                                <div>
                                    <h4 className="font-semibold text-white mb-2">1. QR Kodu Taratın</h4>
                                    <p className="text-sm text-gray-400">
                                        Telefonunuzdaki Authenticator uygulamasını açın ve soldaki QR kodu taratın.
                                    </p>
                                    <div className="mt-4 p-3 bg-black/20 rounded-lg border border-gray-800 flex items-center justify-between">
                                        <code className="text-xs font-mono text-gray-300">{secret}</code>
                                        <button onClick={copySecret} className="text-gray-400 hover:text-white">
                                            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                        </button>
                                    </div>
                                </div>

                                <div>
                                    <h4 className="font-semibold text-white mb-2">2. Doğrulama Kodunu Girin</h4>
                                    <div className="flex gap-2">
                                        <input
                                            type="text"
                                            value={verifyCode}
                                            onChange={(e) => setVerifyCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                                            placeholder="000 000"
                                            className="bg-[#0f0f13] border border-gray-700 rounded-lg px-4 py-2 text-white w-32 text-center tracking-widest text-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                                        />
                                        <button
                                            onClick={verifyAndActivate}
                                            disabled={verifyCode.length !== 6 || loading}
                                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                            {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : 'Doğrula ve Bitir'}
                                        </button>
                                    </div>
                                </div>

                                <button
                                    onClick={() => setShowEnroll(false)}
                                    className="text-sm text-gray-500 hover:text-gray-300 mt-4"
                                >
                                    İptal Et
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Security Log (Placeholder for future) */}
            <div className="p-6 rounded-2xl border bg-opacity-50" style={{ background: 'var(--color-surface-1)', borderColor: 'var(--color-border)' }}>
                <div className="flex items-center gap-3 mb-4">
                    <Lock className="w-5 h-5 text-gray-400" />
                    <h3 className="text-lg font-bold" style={{ color: 'var(--color-text-0)' }}>Güvenlik Günlüğü</h3>
                </div>
                <div className="text-sm text-gray-500 flex items-center gap-2 p-3 bg-blue-500/5 border border-blue-500/10 rounded-lg">
                    <AlertTriangle className="w-4 h-4 text-blue-500" />
                    <span>Son başarılı giriş: {new Date().toLocaleDateString('tr-TR')} (Bu cihaz)</span>
                </div>
            </div>
        </div>
    )
}

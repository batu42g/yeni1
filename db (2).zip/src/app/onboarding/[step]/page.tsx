'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useAuthStore } from '@/store/auth-store'

import ProfileCompletionStep from '@/components/onboarding/ProfileCompletionStep'
import CompanyCreationStep from '@/components/onboarding/CompanyCreationStep'
import CompanySelectionStep from '@/components/onboarding/CompanySelectionStep'
import TeamSetupStep from '@/components/onboarding/TeamSetupStep'
import BillingSetupStep from '@/components/onboarding/BillingSetupStep'

export default function OnboardingStepPage() {
    const router = useRouter()
    const { step } = useParams()
    const { user, loading } = useAuthStore()
    const [verifying, setVerifying] = useState(true)

    useEffect(() => {
        if (loading) return

        if (!user) {
            router.push('/login')
            return
        }

        const currentStep = user.onboarding?.current_step.toLowerCase()

        if (user.onboarding?.is_completed || currentStep === 'finished') {
            router.push('/dashboard')
            return
        }

        if (currentStep !== step) {
            // User is trying to access wrong step, redirect to current allowed step
            router.push(`/onboarding/${currentStep}`)
            return
        }

        setVerifying(false)
    }, [user, loading, step, router])

    const handleCompleteStep = async (nextStep?: string) => {
        // We generally rely on the bootstrap to compute next step, but we can pass 'FINISHED' if explicitly done
        // Or we can just call an endpoint that computes the next step and refreshes user context
        try {
            // Let server compute the next step if we don't know it. Since we just update the DB usually
            // Wait, the complete-step API expects the EXACT step that is now COMPLETED or the NEW step?
            // Actually complete-step endpoint sets the `current_step` property.
            // But wait, our API was: `complete-step` takes `step` as the *new* step.
            // Actually, the new bootstrap logic is auto-computed!
            // All we need to do is tell the server "hey, re-evaluate my step" or we can pass a dummy update.
            // Let's just refetch bootstrap.

            // First we can make a dummy update or refresh token
            const res = await fetch('/api/context/bootstrap')
            if (res.ok) {
                const data = await res.json()
                useAuthStore.getState().setUser({
                    id: data.user.id,
                    active_company_id: data.active_company_id,
                    role: data.role,
                    full_name: data.user.full_name,
                    avatar_url: data.user.avatar_url,
                    email: data.user.email || '',
                    onboarding: data.onboarding
                })

                const newStep = data.onboarding.current_step.toLowerCase()
                if (data.onboarding.is_completed || newStep === 'finished') {
                    router.push('/dashboard')
                } else {
                    router.push(`/onboarding/${newStep}`)
                }
            }
        } catch (e) {
            console.error('Failed to advance step', e)
        }
    }

    // Force step completion updating
    const updateOnboardingStep = async (newStep: string) => {
        try {
            const resp = await fetch('/api/onboarding/complete-step', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ step: newStep })
            })
            if (resp.ok) await handleCompleteStep()
        } catch (e) {
            console.error('Update step error', e)
        }
    }

    if (loading || verifying) return <div className="text-center text-sm" style={{ color: 'var(--color-text-3)' }}>Aşama doğrulanıyor...</div>

    switch (step) {
        case 'profile_completion':
            return <ProfileCompletionStep onComplete={() => handleCompleteStep()} />
        case 'company_creation':
            return <CompanyCreationStep onComplete={() => handleCompleteStep()} />
        case 'company_selection':
            return <CompanySelectionStep onComplete={() => handleCompleteStep()} />
        case 'team_setup':
            return <TeamSetupStep onComplete={() => updateOnboardingStep('FINISHED')} onSkip={() => updateOnboardingStep('FINISHED')} />
        case 'billing_setup':
            return <BillingSetupStep onComplete={() => updateOnboardingStep('FINISHED')} />
        default:
            return (
                <div className="text-center">
                    <h2 className="text-xl font-bold mb-4">Hazırlanıyor...</h2>
                    <p className="text-sm opacity-60">Sistem ayarlarınız güncelleniyor.</p>
                </div>
            )
    }
}

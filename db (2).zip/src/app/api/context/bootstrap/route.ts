import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET() {
    try {
        const supabase = await createClient()

        // 1. Authenticate Request
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        // 2. Initialize onboarding if needed
        await (supabase.rpc as any)('initialize_user_onboarding', { p_user_id: user.id })

        // 3. Ensure user context and get profile
        const { data: profile, error: profileError } = await (supabase.rpc as any)('ensure_user_context').maybeSingle()

        if (profileError && profileError.code !== 'PGRST116') {
            console.error('Bootstrap context error:', profileError)
            return NextResponse.json({ error: 'Failed to ensure user context' }, { status: 500 })
        }

        const typedProfile = profile as any
        let activeCompanyId = typedProfile?.company_id || null

        // 4. Get active memberships for switcher
        const { data: memberships } = await supabase
            .from('members')
            .select('company_id, role, status, companies(id, name, logo_url, status)')
            .eq('user_id', user.id)

        const activeMemberships = memberships?.filter((m: any) => m.status === 'active') || []

        const validCompanies = activeMemberships
            .filter((m: any) => m.companies)
            .map((m: any) => ({
                ...m.companies,
                role: m.role
            }))

        // 5. Build onboarding state
        const { data: onboarding } = await (supabase.from as any)('user_onboarding')
            .select('*')
            .eq('user_id', user.id)
            .single()

        let isCompleted = onboarding?.is_completed || false
        let currentStep = onboarding?.current_step || 'INIT'

        if (!isCompleted) {
            let companyStatus = 'active'
            if (activeCompanyId) {
                const comp = validCompanies.find((c: any) => c.id === activeCompanyId)
                if (comp) companyStatus = comp.status
                else {
                    const { data: singleComp } = await supabase
                        .from('companies')
                        .select('status')
                        .eq('id', activeCompanyId)
                        .single()
                    if (singleComp) companyStatus = singleComp.status
                }
            }

            const { count: pendingInvites } = await supabase
                .from('invitations')
                .select('*', { count: 'exact', head: true })
                .eq('email', user.email || '')
                .eq('accepted', false)

            if (activeMemberships.length === 0) {
                if (pendingInvites && pendingInvites > 0) {
                    currentStep = 'COMPANY_SELECTION'
                } else {
                    currentStep = 'COMPANY_CREATION'
                }
            } else if (!activeCompanyId || companyStatus === 'archived') {
                currentStep = 'COMPANY_SELECTION'
            } else if (!typedProfile?.full_name || typedProfile.full_name.trim() === '') {
                currentStep = 'PROFILE_COMPLETION'
            } else if (typedProfile?.role === 'owner' || typedProfile?.role === 'admin') {
                const { count: teamCount } = await supabase
                    .from('members')
                    .select('*', { count: 'exact', head: true })
                    .eq('company_id', activeCompanyId)
                    .eq('status', 'active')

                if (teamCount === 1) {
                    currentStep = 'TEAM_SETUP'
                } else {
                    currentStep = 'FINISHED'
                }
            } else {
                currentStep = 'FINISHED'
            }

            if (currentStep === 'FINISHED') {
                isCompleted = true
                await (supabase.from as any)('user_onboarding').update({
                    current_step: 'FINISHED',
                    is_completed: true,
                    completed_at: new Date().toISOString()
                }).eq('user_id', user.id)
            } else if (currentStep !== onboarding?.current_step) {
                await (supabase.from as any)('user_onboarding').update({
                    current_step: currentStep
                }).eq('user_id', user.id)
            }
        }

        return NextResponse.json({
            user: {
                id: user.id,
                full_name: typedProfile?.full_name || '',
                avatar_url: typedProfile?.avatar_url || null,
                email: user.email
            },
            active_company_id: activeCompanyId,
            role: typedProfile?.role || 'staff',
            companies: validCompanies,
            onboarding: {
                is_completed: isCompleted,
                current_step: currentStep
            }
        })

    } catch (error: any) {
        console.error('Bootstrap API error:', error)
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
    }
}

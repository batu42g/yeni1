import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { sanitizeAuditMetadata } from '@/lib/audit'
import { logPermissionDenied } from '@/lib/permission-audit'

export async function GET(req: Request) {
    try {
        const supabase = await createClient()

        const { data: { user } } = await supabase.auth.getUser()
        if (!user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const { data: profile } = await supabase.rpc('ensure_user_context').maybeSingle()

        if (!profile || !profile.company_id) {
            await logPermissionDenied({ endpoint: '/api/audit', method: 'GET', targetType: 'audit_logs', reason: 'NO_COMPANY_CONTEXT' })
            return NextResponse.json({ error: 'Company context required' }, { status: 403 })
        }

        // Audit requires admin role
        if (profile.role !== 'admin' && profile.role !== 'owner') {
            await logPermissionDenied({ endpoint: '/api/audit', method: 'GET', targetType: 'audit_logs', requiredRole: 'admin', reason: 'NOT_ADMIN' })
            return NextResponse.json({ error: 'Forbidden. Admin access required.' }, { status: 403 })
        }

        const { searchParams } = new URL(req.url)
        const limitStr = searchParams.get('limit') || '100'
        const limit = parseInt(limitStr, 10)

        let query = supabase
            .from('audit_logs')
            .select(`
                *,
                actor:users!audit_logs_actor_user_id_fkey(full_name, email)
            `)
            .order('created_at', { ascending: false })
            .limit(limit)

        const { data, error } = await query

        if (error) {
            console.error('Audit fetch error:', error)
            return NextResponse.json({ error: 'Failed to fetch audit logs' }, { status: 500 })
        }

        const sanitizedLogs = data?.map(log => ({
            ...log,
            metadata: sanitizeAuditMetadata(log.action, log.metadata)
        }))

        return NextResponse.json({ logs: sanitizedLogs })

    } catch (e) {
        console.error('API Error:', e)
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
    }
}

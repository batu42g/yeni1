import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { logPermissionDenied } from '@/lib/permission-audit'

export async function GET() {
    try {
        const supabase = await createClient()

        const { data: { user } } = await supabase.auth.getUser()
        if (!user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const { data: profile } = await supabase.rpc('ensure_user_context').maybeSingle()
        if (!profile || !profile.company_id) {
            await logPermissionDenied({ endpoint: '/api/compliance/stats', method: 'GET', targetType: 'compliance', reason: 'NO_COMPANY_CONTEXT' })
            return NextResponse.json({ error: 'Company context required' }, { status: 403 })
        }

        if (profile.role !== 'admin' && profile.role !== 'owner') {
            await logPermissionDenied({ endpoint: '/api/compliance/stats', method: 'GET', targetType: 'compliance', requiredRole: 'admin', reason: 'NOT_ADMIN' })
            return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
        }

        const companyId = profile.company_id

        // Get all member IDs of this company to query global events (like LOGIN_FAILED) for these users
        const { data: members } = await supabase
            .from('members')
            .select('user_id')
            .eq('company_id', companyId)

        const memberIds = members?.map(m => m.user_id).filter(Boolean) || []

        // Total audit logs (Company scoped)
        const { count: totalAuditLogs } = await supabase
            .from('audit_logs')
            .select('*', { count: 'exact', head: true })
            .eq('company_id', companyId)

        // Critical events last 24h
        const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()

        const { count: last24hCritical } = await supabase
            .from('audit_logs')
            .select('*', { count: 'exact', head: true })
            .eq('severity', 'critical')
            .eq('company_id', companyId)
            .gte('created_at', since24h)

        const { count: last24hWarning } = await supabase
            .from('audit_logs')
            .select('*', { count: 'exact', head: true })
            .eq('severity', 'warning')
            .eq('company_id', companyId)
            .gte('created_at', since24h)

        // Failed logins last 24h (Global event scoped to current company members)
        let failedLogins24h = 0
        if (memberIds.length > 0) {
            const { count } = await supabase
                .from('audit_logs')
                .select('*', { count: 'exact', head: true })
                .eq('action', 'LOGIN_FAILED')
                .in('actor_user_id', memberIds)
                .gte('created_at', since24h)
            failedLogins24h = count || 0
        }

        // Permission denied last 24h (Company scoped)
        const { count: permissionDenied24h } = await supabase
            .from('audit_logs')
            .select('*', { count: 'exact', head: true })
            .eq('action', 'PERMISSION_DENIED')
            .eq('company_id', companyId)
            .gte('created_at', since24h)

        // Fetch dynamic compliance status from DB
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const { data: complianceStatus } = await (supabase as any).rpc('fn_get_compliance_status')
        const isCronActive = complianceStatus && typeof complianceStatus === 'object' ? complianceStatus.is_retention_cron_active : false
        const isImmutableActive = complianceStatus && typeof complianceStatus === 'object' ? complianceStatus.is_immutable_trigger_active : false

        return NextResponse.json({
            totalAuditLogs: totalAuditLogs || 0,
            last24hCritical: last24hCritical || 0,
            last24hWarning: last24hWarning || 0,
            failedLogins24h: failedLogins24h || 0,
            permissionDenied24h: permissionDenied24h || 0,
            auditRetention: '2 Yıl',
            activityRetention: isCronActive ? '180 Gün (Otomatik)' : '180 Gün (Manuel)',
            immutablePolicy: isImmutableActive,
            piiSanitized: true, // Application level behavior
            exportSanitized: true // Application level behavior
        })
    } catch (e) {
        console.error('Compliance stats error:', e)
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
    }
}

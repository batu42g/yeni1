import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { logPermissionDenied } from '@/lib/permission-audit'

export async function GET(req: Request) {
    try {
        const supabase = await createClient()

        const { data: { user } } = await supabase.auth.getUser()
        if (!user) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const { data: profile } = await supabase.rpc('ensure_user_context').maybeSingle()

        if (!profile || !profile.company_id) {
            await logPermissionDenied({ endpoint: '/api/activity', method: 'GET', targetType: 'activity', reason: 'NO_COMPANY_CONTEXT' })
            return NextResponse.json({ error: 'Company context required' }, { status: 403 })
        }

        const { searchParams } = new URL(req.url)
        const limitStr = searchParams.get('limit') || '50'
        const limit = parseInt(limitStr, 10)

        let query = supabase
            .from('activity_events')
            .select(`
                *,
                actor:users!activity_events_actor_user_id_fkey(full_name, avatar_url)
            `)
            .eq('company_id', profile.company_id)
            .order('created_at', { ascending: false })
            .limit(limit)

        const { data, error } = await query

        if (error) {
            console.error('Activity fetch error:', error)
            return NextResponse.json({ error: 'Failed to fetch activity logs' }, { status: 500 })
        }

        return NextResponse.json({ events: data })

    } catch (e) {
        console.error('API Error:', e)
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
    }
}

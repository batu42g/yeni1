import { create } from 'zustand'
import type { UserRole } from '@/types/database'

interface UserProfile {
    id: string
    active_company_id: string | null
    role: UserRole
    full_name: string
    avatar_url: string | null
    email: string
    onboarding?: {
        is_completed: boolean
        current_step: string
    }
}

interface AuthState {
    user: UserProfile | null
    loading: boolean
    setUser: (user: UserProfile | null) => void
    setLoading: (loading: boolean) => void
    isAdmin: () => boolean
}

export const useAuthStore = create<AuthState>((set, get) => ({
    user: null,
    loading: true,
    setUser: (user) => set({ user }),
    setLoading: (loading) => set({ loading }),
    isAdmin: () => {
        const user = get().user
        if (!user || !user.active_company_id) return false
        return user.role === 'admin' || user.role === 'owner'
    },
}))
